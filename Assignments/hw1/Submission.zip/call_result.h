#ifndef CALLRESULT_H
#define CALLRESULT_H

typedef enum callResult_t
{
    ASSIGN_SUCCESS,
    ASSIGN_MEMORY,
    ASSIGN_NULL,
    ASSIGN_UNK_ERROR
} CallResult;

#endif // ASSIGN_H